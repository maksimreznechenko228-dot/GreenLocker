package com.example.greenlocker;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.text.InputType;

public class MainActivity extends Activity {
    private static final String PASSWORD = "19772012";
    private EditText input;
    private LinearLayout root;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        showLocker();
    }

    private void showLocker() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(32, 40, 32, 40);
        root.setBackgroundColor(Color.rgb(10, 10, 12));

        TextView title = new TextView(this);
        title.setText("ТЕЛЕФОН ЗАБЛОКИРОВАН");
        title.setTextColor(Color.WHITE);
        title.setTextSize(23);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrap());

        TextView hint = new TextView(this);
        hint.setText("Введите пароль для разблокировки");
        hint.setTextColor(Color.LTGRAY);
        hint.setTextSize(16);
        hint.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hp = matchWrap();
        hp.topMargin = 24;
        root.addView(hint, hp);

        input = new EditText(this);
        input.setSingleLine(true);
        input.setGravity(Gravity.CENTER);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(Color.GRAY);
        input.setHint("Пароль");
        input.setTextSize(22);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        ip.topMargin = 24;
        root.addView(input, ip);

        Button unlock = new Button(this);
        unlock.setText("РАЗБЛОКИРОВАТЬ");
        LinearLayout.LayoutParams bp = matchWrap();
        bp.topMargin = 18;
        root.addView(unlock, bp);

        unlock.setOnClickListener(v -> {
            if (PASSWORD.equals(input.getText().toString())) {
                Toast.makeText(this, "Разблокировано!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                input.setText("");
                Toast.makeText(this, "Неверный пароль", Toast.LENGTH_SHORT).show();
            }
        });

        TextView note = new TextView(this);
        note.setText("Демонстрационный экран. Системный выход Android остаётся доступен.");
        note.setTextColor(Color.GRAY);
        note.setTextSize(12);
        note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams np = matchWrap();
        np.topMargin = 32;
        root.addView(note, np);

        setContentView(root);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
    }
}
