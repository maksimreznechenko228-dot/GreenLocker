GREEN LOCKER — Android Studio-free cloud build

Password: 19772012

This is a harmless demo lock screen:
- It only locks its own app screen.
- Android system navigation and emergency exit remain available.
- It does not change the real device lock screen or device security settings.
- No network access and no data collection.

Build an APK without Android Studio:
1. Sign in to GitHub and create a new empty repository.
2. Extract this ZIP and upload all its contents (including the .github folder)
   to the repository.
3. Open the repository's Actions tab.
4. Select "Build Android APK" and press "Run workflow".
5. Wait for the run to finish, open it, and download the
   "GreenLocker-debug-apk" artifact.
6. Extract the downloaded artifact ZIP to get app-debug.apk.
7. Install only on a device you own, after reviewing Android's install warning.

The APK is unsigned debug build, suitable for testing. This environment cannot
run the Android SDK build itself, so the cloud workflow must compile it.
